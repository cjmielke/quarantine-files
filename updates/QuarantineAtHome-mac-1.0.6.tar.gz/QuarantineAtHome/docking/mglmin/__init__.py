CRITICAL_DEPENDENCIES = []
NONCRITICAL_DEPENDENCIES = ['numpy', 'MolKit', 'Pmw', 'bhtree', '_subprocess', 'Pmv', 'ViewerFramework', 'PIL', 'FlexTree', 'idlelib', 'DejaVu','distutils', 'Support']
#__revision__= 'Jun_07_13'
__revision__= 'Sep_17_14'
