## for the windows port

This directory holds precompiled binaries for Autodock and Autogrid.
If you are helping develop the windows port, download them seperately and copy them here so pyinstaller can find them

filenames are stored in the local .gitignore
