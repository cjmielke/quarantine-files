# This package provides support for setting up and updating MGLTools.
# Author: Sargis Dallakyan (sargis at scripps.edu) $
# $Header: /opt/cvs/Support/__init__.py,v 1.1 2006/11/28 00:47:22 sargis Exp $
# $Id: __init__.py,v 1.1 2006/11/28 00:47:22 sargis Exp $
